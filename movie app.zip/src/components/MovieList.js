import React, { useState, useEffect } from "react";
import axios from "axios";
import { Link } from "react-router-dom";
import Navbar from "./Navbar";

const MovieList = () => {
  const [movies, setMovies] = useState([]);

  useEffect(() => {
    const fetchData = async () => {
      try {
        const response = await axios.get(
          "https://api.tvmaze.com/search/shows?q=all"
        );
        setMovies(response.data);
      } catch (error) {
        console.error("Error fetching data:", error);
      }
    };

    fetchData();
  }, []);

  return (
    <>
      <Navbar />
      <div className="container mx-auto p-10">
        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6">
          {movies.map((movie) => (
            <div
              key={movie.show.id}
              className="bg-white p-4 rounded-lg shadow-md"
            >
              <img
                src={movie.show.image && movie.show.image.medium}
                alt={movie.show.name}
                className="w-full h-auto mb-4"
              />
              <div className="flex justify-between">
              <h2 className="text-xl font-semibold mb-2">{movie.show.name}</h2>
              <Link
                to={`/moviedetails/${movie.show.id}`}
                className="bg-red-500 text-white px-4 py-2 rounded-lg inline-block hover:bg-red-600"
              >
                Details
              </Link>
              </div>
            </div>
          ))}
        </div>
      </div>
    </>
  );
};

export default MovieList;
