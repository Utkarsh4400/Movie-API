import React, { useState, useEffect } from "react";
import axios from "axios";
import { useParams } from "react-router-dom";

const MovieDetail = () => {
  const { id } = useParams();
  const [movie, setMovie] = useState(null);
  const [isModalOpen, setIsModalOpen] = useState(false);

  useEffect(() => {
    const fetchMovie = async () => {
      try {
        const response = await axios.get(
          `https://api.tvmaze.com/shows/${id}`
        );
        setMovie(response.data);
      } catch (error) {
        console.error("Error fetching movie:", error);
      }
    };

    fetchMovie();
  }, [id]);

  const handleBookTicket = () => {
    setIsModalOpen(true);
  };

  const handleCloseModal = () => {
    setIsModalOpen(false);
  };

  // Function to strip HTML tags
  const stripHtmlTags = (html) => {
    return html.replace(/<[^>]*>?/gm, '');
  };

  return (
    <div className="container mx-auto h-full flex justify-center items-center p-20">
      {movie && (
        <div className="max-w-3xl w-full bg-white p-8 rounded-lg shadow-lg">
          <h1 className="text-3xl font-semibold mb-6">{movie.name}</h1>
          <div className="flex flex-col lg:flex-row">
            <div className="w-full lg:w-1/3">
              <img
                src={movie.image && movie.image.medium}
                alt={movie.name}
                className="w-full h-auto"
              />
            </div>
            <div className="w-full lg:w-2/3 px-6 py-4">
              <p className="text-lg mb-4">{stripHtmlTags(movie.summary)}</p>
              <button
                onClick={handleBookTicket}
                className="bg-red-500 text-white px-4 py-2 rounded-lg hover:bg-red-600"
              >
                Book Ticket
              </button>
            </div>
          </div>
        </div>
      )}
      {isModalOpen && (
        <div className="fixed inset-0 flex justify-center items-center z-50 bg-gray-800 bg-opacity-50">
          <div className="bg-white p-10 rounded-lg">
            <h2 className="text-xl font-semibold mb-4">Confirm Booking</h2>
            <p className="mb-4">Movie: {movie.name}</p>
            <div className="flex justify-end">
              <button
                className="bg-green-500 text-white font-semibold px-4 py-2 rounded mr-2 hover:bg-green-600"
                onClick={handleCloseModal}
              >
                Confirm
              </button>
              <button
                className="bg-gray-300 text-gray-700 font-semibold px-4 py-2 rounded hover:bg-gray-400"
                onClick={handleCloseModal}
              >
                Cancel
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default MovieDetail;
